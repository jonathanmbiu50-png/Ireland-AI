# Sirjnet AI v0.2

A Next.js + PostgreSQL foundation for a dual-mode AI platform:
- Private workspace for registering apps/websites the owner controls.
- Developer platform with scoped API keys.
- API chat endpoint and integration-list endpoint.
- Audit records for key and integration events.
- Defensive security scope reserved for future authorised scanning.

## Run locally
1. Install Node.js 20+ and PostgreSQL.
2. Copy `.env.example` to `.env` and set `DATABASE_URL`, `AUTH_SECRET` (32+ random characters), and `OPENAI_API_KEY`.
3. Run `npm install`
4. Run `npx prisma generate && npx prisma db push`
5. Run `npm run dev`, then open http://localhost:3000.

## API
Create a developer key in the dashboard. It is shown once. Keep it on a trusted server.

`POST /api/v1/chat` with `Authorization: Bearer YOUR_KEY` and JSON `{"message":"Hello"}` requires `chat:write`.

`GET /api/v1/integrations` requires `integrations:read`.

## Current boundaries
This is a working foundation, not a finished autonomous app-control product. Adding a URL registers metadata only; it does not log into that app, read its data, or execute actions. Real integrations need provider OAuth/API credentials, explicit scopes, callback validation, encrypted secret storage, rate limits and per-action confirmation. The `security:scan` scope is reserved; no network scanner is included. Future security checks should be limited to systems the account owner controls or has explicit permission to test.

Before production: add email verification, password reset, CSRF/rate limiting, stricter SSRF protections for outbound connectors, encrypted provider tokens, webhook signature verification, key rotation, billing, monitoring, backups and a formal privacy policy.

## Deploy on Render
The included `render.yaml` creates a web service and PostgreSQL database. The selected plans may incur charges. Review costs in Render before approving deployment. Add `OPENAI_API_KEY` as a secret in Render.


## Deployment notes (v0.3.1)

- The Prisma schema is formatted as valid multi-line Prisma blocks.
- Set `DATABASE_URL`, `AUTH_SECRET`, and `OPENAI_API_KEY` as private Render environment variables.
- Set `OPENAI_BASE_URL` to `https://api.openai.com/v1` and `AI_MODEL` to a model available to your API account.
- The integrations screen is currently a permission/scope registry; it does not yet connect to or control other apps.
- This is a responsive web app/PWA, not a native Android APK. An Android wrapper and successful APK build are separate work.
- Cybersecurity functions must be used only for defensive, authorised testing.
