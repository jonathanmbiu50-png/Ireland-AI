import { currentUserId } from "@/lib/auth";
import { db } from "@/lib/db";
import { Dashboard } from "@/components/dashboard";
export default async function Home() {
 const userId=await currentUserId();
 const integrations=userId?await db.integration.findMany({where:{userId},orderBy:{createdAt:"desc"}}):[];
 return <Dashboard signedIn={!!userId} integrations={integrations.map(x=>({id:x.id,name:x.name,baseUrl:x.baseUrl,scopes:x.scopes,status:x.status}))}/>;
}
