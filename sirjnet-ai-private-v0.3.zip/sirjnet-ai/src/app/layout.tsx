import "./style.css";
import type { Metadata } from "next";
export const metadata: Metadata = {title:"Sirjnet AI",description:"Your private personal AI assistant"};
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }
