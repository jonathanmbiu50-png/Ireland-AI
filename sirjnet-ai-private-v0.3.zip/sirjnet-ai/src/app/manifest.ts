import type { MetadataRoute } from "next";
export default function manifest(): MetadataRoute.Manifest { return {name:"Sirjnet AI",short_name:"Sirjnet",description:"Your private personal AI assistant",start_url:"/",display:"standalone",background_color:"#080b12",theme_color:"#080b12",icons:[{src:"/icon.svg",sizes:"any",type:"image/svg+xml"}]};}
