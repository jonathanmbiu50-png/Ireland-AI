export const AVAILABLE_SCOPES = ["chat:write","integrations:read","integrations:write","security:scan"] as const;
export type Scope = typeof AVAILABLE_SCOPES[number];
export function hasScope(granted:string[], needed:Scope) { return granted.includes(needed); }
