import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
const secret = new TextEncoder().encode(process.env.AUTH_SECRET || "development-only-change-this-secret");
export async function makeSession(userId: string) {
  const token = await new SignJWT({sub:userId}).setProtectedHeader({alg:"HS256"}).setIssuedAt().setExpirationTime("7d").sign(secret);
  (await cookies()).set("sirjnet_session", token, {httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",path:"/",maxAge:604800});
}
export async function currentUserId() {
  const token = (await cookies()).get("sirjnet_session")?.value;
  if (!token) return null;
  try { return (await jwtVerify(token,secret)).payload.sub as string; } catch { return null; }
}
